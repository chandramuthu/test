package com.cg.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
@Table(name="insurance101")
@Entity
public class Insurance {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "a")
	@SequenceGenerator(name = "a", sequenceName = "insurancesq3")
	@Column(length = 15)
	private int id;
	/*@Min(4)
	@Max(20)*/
	@Column(length = 15)
	private String vehicleModel;
	/*@Min(4)
	@Max(20)*/
	@Column(length = 15)
	private double onRoadPrice;
	/*@Min(4)
	@Max(20)*/
	@Column(length = 10)
	private int purchaseYear;
	@Column(length = 20)
	private Double insuranceAmount;
	/*@Min(9)
	@Max(11)*/
	private Date expDate;
	public Insurance() {
		super();
	}
	public Insurance(int id, String vehicleModel, double onRoadPrice, int purchaseYear, Double insuranceAmount,
			Date expDate) {
		super();
		this.id = id;
		this.vehicleModel = vehicleModel;
		this.onRoadPrice = onRoadPrice;
		this.purchaseYear = purchaseYear;
		this.insuranceAmount = insuranceAmount;
		this.expDate = expDate;
	}
	@Override
	public String toString() {
		return "Insurance [id=" + id + ", vehicleModel=" + vehicleModel + ", onRoadPrice=" + onRoadPrice
				+ ", purchaseYear=" + purchaseYear + ", insuranceAmount=" + insuranceAmount + ", expDate=" + expDate
				+ "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}
	public double getOnRoadPrice() {
		return onRoadPrice;
	}
	public void setOnRoadPrice(double onRoadPrice) {
		this.onRoadPrice = onRoadPrice;
	}
	public int getPurchaseYear() {
		return purchaseYear;
	}
	public void setPurchaseYear(int purchaseYear) {
		this.purchaseYear = purchaseYear;
	}
	public Double getInsuranceAmount() {
		return insuranceAmount;
	}
	public void setInsuranceAmount(Double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	

}
