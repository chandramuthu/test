package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.entity.Insurance;
import com.cg.entity.TransactionEntity;

public interface InsuranceService {

	public List<Insurance> addInsurance(Insurance insurance);

	

	public double calculateInsuranceAmount(double price, int year);

	public List<Insurance> updateInsurance(Integer id, Insurance insurance);

	public void deleteInsurance(Integer id);



	public Optional<Insurance> viewInsuranceById(Integer id);



	public List<Insurance> viewAllInsurance();



	public Optional<List<Insurance>> viewAll(int purchaseyear);

	

}
