package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.dao.InsuranceDao;
import com.cg.entity.Insurance;
import com.cg.entity.TransactionEntity;

@Service
public class InsuranceServiceImpl implements InsuranceService {

	@Autowired
	InsuranceDao insuranceDao;

	

	public List<Insurance> addInsurance(Insurance insurance) {
		insuranceDao.save(insurance);
		return insuranceDao.findAll();
	}

	@Override
	public double calculateInsuranceAmount(double price, int year) {
		int time=2019-year;
		int a=time*5;
		double price1= (price-(price*a/100));
		double ins=(price1*2.5/100);
		return ins;
	}

	@Override
	public List<Insurance> updateInsurance(Integer id, Insurance insurance) {
		Optional<Insurance> e=insuranceDao.findById(id);
		Insurance e1=e.get();
		
		
		e1.setInsuranceAmount(insurance.getInsuranceAmount());
		e1.setOnRoadPrice(insurance.getOnRoadPrice());
		e1.setPurchaseYear(insurance.getPurchaseYear());
		e1.setVehicleModel(insurance.getVehicleModel());
		e1.setExpDate(insurance.getExpDate());
		
		insuranceDao.save(e1);
		
		return insuranceDao.findAll();
	}

	@Override
	public void deleteInsurance(Integer id) {
		insuranceDao.deleteById(id);
		
	}

	@Override
	public Optional<Insurance> viewInsuranceById(Integer id) {
		return insuranceDao.findById(id);
	}

	@Override
	public List<Insurance> viewAllInsurance() {
		return insuranceDao.findAll();
	}

	@Override
	public Optional<List<Insurance>> viewAll(int purchaseyear) {
		
		return insuranceDao.viewAll(purchaseyear);
	}

	
}
