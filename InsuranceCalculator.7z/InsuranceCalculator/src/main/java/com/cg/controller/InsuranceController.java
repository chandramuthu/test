package com.cg.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Insurance;
import com.cg.entity.TransactionEntity;
import com.cg.service.InsuranceService;

@RestController
@RequestMapping("/Insurance")
public class InsuranceController {
	@Autowired
	InsuranceService insuranceService;

	@PostMapping("/AddInsurance")
	public List<Insurance> addInsurance(@RequestBody Insurance insurance) {
	
	
		double price=insurance.getOnRoadPrice();
		int year=insurance.getPurchaseYear();
		double ins=insuranceService.calculateInsuranceAmount(price,year);
		insurance.setInsuranceAmount(ins);
		Calendar cal=Calendar.getInstance();
		
		cal.add(Calendar.YEAR, 1);
		Date today=cal.getTime();
		insurance.setExpDate(today);
		
		return insuranceService.addInsurance(insurance);
	}
	
	/*public ResponseEntity<String> deposit(@PathVariable Long accNo, @PathVariable Double amt) {*/
	/*@PutMapping("/UpdateInsurance")
		public List<Insurance> updateInsurance(@RequestBody Insurance insurance) 
		{
		return insuranceService.updateInsurance(insurance);
		Double bal = insuranceService.updateInsurance(accNo, amt);
		return new ResponseEntity<String>("Your Current Balance is " + bal, HttpStatus.OK);
	}
	
	
	@PutMapping("/update/{eid}/{amt}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable int eid,@PathVariable int amt)
   
    {
        Employee i= service.updateEmployee(eid,amt);
        return new ResponseEntity<Employee>(i,HttpStatus.OK);
       
    }*/

/*
	@GetMapping("/AccountDetails/{accNo}")
	public BankEntity accountsDetails(@PathVariable Long accNo) {
		return bankService.accountsDetails(accNo);
	}

	@GetMapping("/ShowBalance/{accNo}")
	public ResponseEntity<String> showBalance(@PathVariable Long accNo) {
		Double bal = bankService.showBalance(accNo);
		return new ResponseEntity<String>("Your Current Balance is " + bal, HttpStatus.OK);
	}

	
	@PutMapping("/Withdraw/{accNo}/{amt}")
	public ResponseEntity<String> withdraw(@PathVariable Long accNo, @PathVariable Double amt) {
		Double bal = bankService.withdraw(accNo, amt);
		return new ResponseEntity<String>("Your Current Balance is " + bal, HttpStatus.OK);
	}

	@PutMapping("/FundTransfer/{accNo1}/{amt}/{accNo2}")
	public ResponseEntity<String> fundTransfer(@PathVariable Long accNo1, @PathVariable Double amt,
			@PathVariable Long accNo2) {
		Double bal = bankService.fundTransfer(accNo1, amt, accNo2);
		return new ResponseEntity<String>("Your Current Balance is " + bal, HttpStatus.OK);
	}

	@GetMapping("/PrintTransaction/{accNo}")
	public List<TransactionEntity> printTransaction(@PathVariable Long accNo) {
		return bankService.printTransaction(accNo);
	}
*/
}
