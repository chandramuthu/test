package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.InsuranceDao;
import com.cg.dao.InsuranceDao2;
import com.cg.entity.Insurance;
import com.cg.entity.TransactionEntity;

@Service
public class InsuranceServiceImpl implements InsuranceService {

	@Autowired
	InsuranceDao insuranceDao;

	@Autowired
	InsuranceDao2 bankDao2;

	public List<Insurance> addInsurance(Insurance insurance) {
		insuranceDao.save(insurance);
		return insuranceDao.findAll();
	}

	@Override
	public List<Insurance> updateInsurance(Insurance insurance) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public double calculateInsuranceAmount(double price, int year) {
		int time=2019-year;
		int a=time*5;
		double price1= (price-(price*a/100));
		double ins=(price1*2.5/100);
		return ins;
	}

	/*@Override
	public List<Insurance> updateInsurance(Insurance insurance) {
		insuranceDao.sa
		return null;
	}*/

	/*public Insurance accountsDetails(Long accNo) {
		return bankDao.findById(accNo).get();
	}

	public Double showBalance(Long accNo) {
		Double bal = bankDao.findById(accNo).get().getBal();
		return bal;
	}

	public Double deposit(Long accNo, Double amt) {

		Optional<Insurance> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			Insurance tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() + amt);
			bankDao.save(tempEntity);
			TransactionEntity trans = new TransactionEntity(accNo, "Deposite", bank.get().getBal(),
					bank.get().getBal() + amt);
			bankDao2.save(trans);
			return showBalance(accNo);
		} else {
			return showBalance(accNo);
		}
	}

	public Double withdraw(Long accNo, Double amt) {
		Optional<Insurance> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			Insurance tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() - amt);
			bankDao.save(tempEntity);
			TransactionEntity trans = new TransactionEntity(accNo, "Withdraw", bank.get().getBal(),
					bank.get().getBal() - amt);
			bankDao2.save(trans);
			return showBalance(accNo);
		} else {
			return showBalance(accNo);
		}
	}

	public Double fundTransfer(Long accNo1, Double amt, Long accNo2) {
		Optional<Insurance> bank1 = bankDao.findById(accNo1);
		Optional<Insurance> bank2 = bankDao.findById(accNo2);
		if (bank1.isPresent() && bank2.isPresent()) {
			Insurance tempEntity = bank1.get();
			tempEntity.setBal(bank1.get().getBal() - amt);
			bankDao.save(tempEntity);
			Insurance tempEntity2 = bank2.get();
			tempEntity2.setBal(bank2.get().getBal() + amt);
			bankDao.save(tempEntity2);
			TransactionEntity trans = new TransactionEntity(accNo1, "Fund Transfer", bank1.get().getBal(),
					bank1.get().getBal() - amt);
			bankDao2.save(trans);
			TransactionEntity trans2 = new TransactionEntity(accNo2, "Fund Recieved", bank2.get().getBal(),
					amt + bank2.get().getBal());
			bankDao2.save(trans2);
			return showBalance(accNo1);
		} else {
			return showBalance(accNo1);
		}
	}

	public List<TransactionEntity> printTransaction(Long accNo) {

		return   bankDao2.printTransaction(accNo);
	}*/
}
