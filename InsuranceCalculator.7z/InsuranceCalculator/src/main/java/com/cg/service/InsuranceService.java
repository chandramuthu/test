package com.cg.service;

import java.util.List;
import com.cg.entity.Insurance;
import com.cg.entity.TransactionEntity;

public interface InsuranceService {

	public List<Insurance> addInsurance(Insurance insurance);

	public List<Insurance> updateInsurance(Insurance insurance);

	public double calculateInsuranceAmount(double price, int year);

	

}
